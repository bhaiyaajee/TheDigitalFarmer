package com.i3AdvancedTech.i3connect;

public class UserProfile
{
    public String Name;
    public String Email;
    public String Phone;
    public String Password;
    public String Gender;

    public UserProfile(String Name , String Email , String Phone, String Password, String Gender)
    {
        this.Name= Name;
        this.Email=Email;
        this.Phone=Phone;
        this.Password=Password;
        this.Gender = Gender;
    }
}